import os
import sys
import site
import time
import logging
import traceback
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional, List
from faster_whisper import WhisperModel

# ============================================================================
# CUDA ENVIRONMENT SETUP
# ============================================================================

def setup_cuda_environment():
    """Configure CUDA libraries for GPU acceleration"""
    site_packages = site.getsitepackages()[0]
    cuda_lib_paths = [
        os.path.join(site_packages, "nvidia", "cudnn", "lib"),
        os.path.join(site_packages, "nvidia", "cublas", "lib"),
        os.path.join(site_packages, "nvidia", "cuda_runtime", "lib"),
    ]
    
    existing_ld_path = os.environ.get('LD_LIBRARY_PATH', '')
    valid_paths = [p for p in cuda_lib_paths if os.path.exists(p)]
    
    if valid_paths:
        new_ld_path = ':'.join(valid_paths)
        if existing_ld_path:
            new_ld_path += ':' + existing_ld_path
        os.environ['LD_LIBRARY_PATH'] = new_ld_path
    
    # Prevent Hugging Face API calls
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'

setup_cuda_environment()

# ============================================================================
# CONFIGURATION
# ============================================================================

# Model Configuration
MODEL_DIR = os.environ.get('WHISPER_MODEL_DIR', '/opt/whisper_models')
MODEL_NAME = os.environ.get('WHISPER_MODEL_NAME', 'large-v3')
COMPUTE_TYPE = os.environ.get('WHISPER_COMPUTE_TYPE', 'float16')
BEAM_SIZE = int(os.environ.get('WHISPER_BEAM_SIZE', '5'))

# Performance Logging
PERF_LOG_DIR = os.environ.get('WHISPER_PERF_LOG_DIR', './performance_logs')

# Language Support
SUPPORTED_LANGUAGES = {
    'te': 'Telugu',
    'hi': 'Hindi',
    'ta': 'Tamil',
    'en': 'English',
}

# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger(__name__)


# ============================================================================
# PERFORMANCE LOGGER - FIXED
# ============================================================================

class PerformanceLogger:
    """
    FIXED: Detailed performance tracking and logging
    Now safely handles both success and error cases
    """
    
    def __init__(self, log_dir: str = PERF_LOG_DIR):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Performance metrics storage
        self.session_metrics = []
        self.session_start = time.time()
        
        # Create timestamped log file
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.log_file = self.log_dir / f'performance_{timestamp}.log'
        
        # Setup performance file logger
        perf_handler = logging.FileHandler(self.log_file)
        perf_handler.setFormatter(logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(message)s'
        ))
        self.perf_logger = logging.getLogger('performance')
        self.perf_logger.addHandler(perf_handler)
        self.perf_logger.setLevel(logging.INFO)
        
        self.perf_logger.info("="*80)
        self.perf_logger.info("PERFORMANCE LOGGING SESSION STARTED")
        self.perf_logger.info("="*80)
    
    def log_processing(self, metrics: Dict):
        """FIXED: Log detailed processing metrics - safely handles errors"""
        self.session_metrics.append(metrics)
        
        self.perf_logger.info("-"*80)
        self.perf_logger.info(f"FILE: {metrics.get('audio_file', 'unknown')}")
        self.perf_logger.info(f"  Status: {metrics.get('status', 'unknown')}")
        
        if metrics.get('status') == 'success':
            # Success case - all fields should be present
            audio_duration = metrics.get('audio_duration_seconds', 0)
            lang_name = metrics.get('language_name', 'Unknown')
            lang_conf = metrics.get('language_confidence', 0)
            
            self.perf_logger.info(f"  Audio Duration: {audio_duration:.2f}s")
            self.perf_logger.info(f"  Detected Language: {lang_name} ({lang_conf:.1%})")
            
            # Timing breakdown
            timings = metrics.get('timings', {})
            trans_time = timings.get('transcription_time', 0)
            trans_ratio = timings.get('transcription_speed_ratio', 0)
            
            self.perf_logger.info(f"  TIMING BREAKDOWN:")
            self.perf_logger.info(f"    - Transcription: {trans_time:.2f}s ({trans_ratio:.2f}x realtime)")
            
            translation_time = timings.get('translation_time')
            if translation_time:
                trans_speed = timings.get('translation_speed_ratio', 0)
                total_time = timings.get('total_time', 0)
                time_saved = timings.get('time_saved_estimate', 0)
                
                self.perf_logger.info(f"    - Translation: {translation_time:.2f}s ({trans_speed:.2f}x realtime)")
                self.perf_logger.info(f"    - Total: {total_time:.2f}s")
                self.perf_logger.info(f"  OPTIMIZATION: Single-pass processing saved ~{time_saved:.2f}s")
            else:
                total_time = timings.get('total_time', 0)
                self.perf_logger.info(f"    - No translation needed (English audio)")
                self.perf_logger.info(f"    - Total: {total_time:.2f}s")
            
            # Efficiency metrics
            overall_ratio = timings.get('overall_speed_ratio', 0)
            overhead_pct = timings.get('overhead_percentage', 0)
            
            self.perf_logger.info(f"  EFFICIENCY:")
            self.perf_logger.info(f"    - Overall Speed Ratio: {overall_ratio:.2f}x realtime")
            self.perf_logger.info(f"    - Processing Overhead: {overhead_pct:.1f}%")
        else:
            # Error case - safely log what's available
            error_msg = metrics.get('error', 'Unknown error')
            self.perf_logger.info(f"  Error: {error_msg}")
            
            # Log traceback if available
            if 'error_traceback' in metrics:
                self.perf_logger.info(f"  Traceback:\n{metrics['error_traceback']}")
    
    def log_session_summary(self, stats: Dict):
        """Log session summary statistics"""
        session_duration = time.time() - self.session_start
        
        self.perf_logger.info("="*80)
        self.perf_logger.info("SESSION SUMMARY")
        self.perf_logger.info("="*80)
        self.perf_logger.info(f"Session Duration: {session_duration:.2f}s")
        self.perf_logger.info(f"Files Processed: {stats.get('processed', 0)}")
        self.perf_logger.info(f"Successful: {stats.get('successful', 0)}")
        self.perf_logger.info(f"Failed: {stats.get('failed', 0)}")
        self.perf_logger.info(f"Total Audio Duration: {stats.get('total_audio_duration', 0):.2f}s")
        self.perf_logger.info(f"Total Processing Time: {stats.get('total_processing_time', 0):.2f}s")
        
        if stats.get('successful', 0) > 0:
            self.perf_logger.info(f"Average Processing Time: {stats.get('avg_processing_time_seconds', 0):.2f}s per file")
            self.perf_logger.info(f"Average Speed Ratio: {stats.get('avg_speed_ratio', 0):.2f}x realtime")
            self.perf_logger.info(f"Estimated Time Saved (vs old method): {stats.get('estimated_time_saved', 0):.2f}s")
        
        self.perf_logger.info(f"Device Used: {stats.get('device', 'unknown')}")
        self.perf_logger.info(f"Model Used: {stats.get('model', 'unknown')}")
        self.perf_logger.info("="*80)
    
    def close(self):
        """Close performance logger"""
        self.perf_logger.info("PERFORMANCE LOGGING SESSION ENDED")
        for handler in self.perf_logger.handlers[:]:
            handler.close()
            self.perf_logger.removeHandler(handler)


# ============================================================================
# WHISPER PROCESSOR - FIXED
# ============================================================================

class WhisperProcessor:
    """
    FIXED: Core Whisper processing class
    Now with proper error handling and safe field access
    """
    
    def __init__(self, 
                 model_name: str = MODEL_NAME,
                 compute_type: str = COMPUTE_TYPE,
                 model_dir: str = MODEL_DIR,
                 enable_perf_logging: bool = True):
        """
        Initialize Whisper processor
        
        Args:
            model_name: Whisper model size (tiny, base, small, medium, large-v2, large-v3)
            compute_type: 'int8' (CPU/lower VRAM), 'float16' (GPU/better quality)
            model_dir: Directory to store/load models
            enable_perf_logging: Enable detailed performance logging
        """
        self.model_name = model_name
        self.compute_type = compute_type
        self.model_dir = model_dir
        
        logger.info("="*80)
        logger.info("INITIALIZING WHISPER PROCESSOR (FIXED)")
        logger.info("="*80)
        logger.info(f"Model: {model_name}")
        logger.info(f"Compute Type: {compute_type}")
        logger.info(f"Model Directory: {model_dir}")
        logger.info(f"Performance Logging: {'ENABLED' if enable_perf_logging else 'DISABLED'}")
        
        # Ensure model directory exists
        Path(model_dir).mkdir(parents=True, exist_ok=True)
        
        # Initialize model
        start_time = time.time()
        self.device = self._initialize_model()
        load_time = time.time() - start_time
        
        logger.info(f"✓ Model loaded in {load_time:.2f}s on {self.device}")
        
        # Statistics tracking
        self.stats = {
            'processed': 0,
            'successful': 0,
            'failed': 0,
            'total_audio_duration': 0.0,
            'total_processing_time': 0.0,
            'estimated_time_saved': 0.0,
        }
        
        # Performance logging
        self.enable_perf_logging = enable_perf_logging
        self.perf_logger = PerformanceLogger() if enable_perf_logging else None
    
    def _initialize_model(self) -> str:
        """
        Initialize Whisper model with GPU fallback to CPU
        
        Returns:
            Device used ('cuda' or 'cpu')
        """
        try:
            logger.info("Attempting GPU (CUDA) initialization...")
            self.model = WhisperModel(
                self.model_name,
                device='cuda',
                compute_type=self.compute_type,
                download_root=self.model_dir,
                num_workers=2,
                cpu_threads=4
            )
            logger.info("✓ GPU enabled")
            return 'cuda'
            
        except Exception as e:
            logger.warning(f"GPU initialization failed: {str(e)[:150]}")
            logger.info("Falling back to CPU mode...")
            
            try:
                self.model = WhisperModel(
                    self.model_name,
                    device='cpu',
                    compute_type='int8',  # CPU always uses int8
                    download_root=self.model_dir,
                    num_workers=4,
                    cpu_threads=8
                )
                logger.info("✓ CPU mode enabled")
                return 'cpu'
                
            except Exception as e:
                logger.error(f"Failed to initialize model on CPU: {e}")
                raise
    
    def process_audio_file(self, 
                          audio_path: str,
                          language: Optional[str] = None,
                          beam_size: int = BEAM_SIZE,
                          save_transcription: bool = True,
                          save_translation: bool = True) -> Dict:
        """
        FIXED: Process audio file with proper error handling
        
        Args:
            audio_path: Path to audio file
            language: Optional language code (auto-detect if None)
            beam_size: Beam search size (1-10, higher=better quality but slower)
            save_transcription: Whether to include native language transcription
            save_translation: Whether to include English translation
        
        Returns:
            Dictionary with processing results - ALWAYS includes 'status' field
        """
        audio_file = Path(audio_path)
        if not audio_file.exists():
            error_result = {
                'audio_file': str(audio_path),
                'status': 'failed',
                'error': f'Audio file not found: {audio_path}',
                'error_type': 'FileNotFoundError',
                'processing': {
                    'model': self.model_name,
                    'device': self.device,
                    'timestamp': datetime.utcnow().isoformat() + 'Z'
                }
            }
            self.stats['processed'] += 1
            self.stats['failed'] += 1
            if self.perf_logger:
                self.perf_logger.log_processing(error_result)
            return error_result
        
        file_name = audio_file.name
        logger.info(f"Processing: {file_name}")
        
        processing_start = time.time()
        
        try:
            # STEP 1: TRANSCRIPTION (Original Language) - ALWAYS REQUIRED
            logger.debug("Step 1: Transcribing audio...")
            transcription_start = time.time()
            
            segments, info = self.model.transcribe(
                str(audio_path),
                language=language,
                task='transcribe',
                beam_size=beam_size,
                vad_filter=True,
                vad_parameters=dict(min_silence_duration_ms=500)
            )
            
            # Collect segments efficiently
            text_parts = []
            segment_list = []
            
            for segment in segments:
                text_parts.append(segment.text)
                if save_transcription:
                    segment_list.append({
                        'start': round(segment.start, 2),
                        'end': round(segment.end, 2),
                        'text': segment.text.strip()
                    })
            
            transcription_text = ' '.join(text_parts).strip()
            transcription_time = time.time() - transcription_start
            
            detected_lang = info.language
            lang_confidence = info.language_probability
            audio_duration = info.duration
            
            logger.info(f"  Language: {SUPPORTED_LANGUAGES.get(detected_lang, detected_lang)} "
                       f"({lang_confidence:.1%})")
            logger.info(f"  Duration: {audio_duration:.1f}s | Transcribed: {transcription_time:.1f}s "
                       f"({audio_duration/transcription_time:.1f}x)")
            
            # STEP 2: TRANSLATION (to English, ONLY if needed)
            translation_result = None
            translation_time = 0
            time_saved_estimate = 0
            
            if save_translation and detected_lang != 'en':
                logger.debug("Step 2: Translating to English...")
                translation_start = time.time()
                
                segments_en, info_en = self.model.transcribe(
                    str(audio_path),
                    language=detected_lang,
                    task='translate',
                    beam_size=beam_size,
                    vad_filter=True,
                    vad_parameters=dict(min_silence_duration_ms=500)
                )
                
                # Collect translation
                translation_parts = []
                for segment in segments_en:
                    translation_parts.append(segment.text)
                
                translation_text = ' '.join(translation_parts).strip()
                translation_time = time.time() - translation_start
                
                translation_result = {
                    'text': translation_text,
                    'processing_time_seconds': round(translation_time, 2)
                }
                
                logger.info(f"  Translated: {translation_time:.1f}s "
                           f"({audio_duration/translation_time:.1f}x)")
            
            elif detected_lang == 'en':
                # OPTIMIZATION: Skip translation for English audio
                logger.info(f"  Translation skipped (English audio)")
                time_saved_estimate = transcription_time * 0.9
                self.stats['estimated_time_saved'] += time_saved_estimate
            
            total_time = time.time() - processing_start
            
            # Build result dictionary - ALL FIELDS PRESENT
            result = {
                'audio_file': file_name,
                'audio_duration_seconds': round(audio_duration, 2),
                'detected_language': detected_lang,
                'language_name': SUPPORTED_LANGUAGES.get(detected_lang, detected_lang),
                'language_confidence': round(lang_confidence, 4),
                'status': 'success'
            }
            
            # Add transcription if requested
            if save_transcription:
                result['transcription'] = {
                    'text': transcription_text,
                    'segments': segment_list,
                    'processing_time_seconds': round(transcription_time, 2)
                }
            
            # Add translation if available
            if translation_result:
                result['translation'] = translation_result
            
            # Add processing metadata with detailed timing
            transcription_speed_ratio = audio_duration / transcription_time if transcription_time > 0 else 0
            translation_speed_ratio = audio_duration / translation_time if translation_time > 0 else 0
            overall_speed_ratio = audio_duration / total_time if total_time > 0 else 0
            overhead = total_time - transcription_time - translation_time
            overhead_percentage = (overhead / total_time * 100) if total_time > 0 else 0
            
            result['processing'] = {
                'model': self.model_name,
                'device': self.device,
                'beam_size': beam_size,
                'total_time_seconds': round(total_time, 2),
                'timestamp': datetime.utcnow().isoformat() + 'Z'
            }
            
            # Add detailed timing breakdown
            result['timings'] = {
                'transcription_time': round(transcription_time, 2),
                'transcription_speed_ratio': round(transcription_speed_ratio, 2),
                'translation_time': round(translation_time, 2) if translation_time > 0 else None,
                'translation_speed_ratio': round(translation_speed_ratio, 2) if translation_time > 0 else None,
                'total_time': round(total_time, 2),
                'overall_speed_ratio': round(overall_speed_ratio, 2),
                'overhead_seconds': round(overhead, 2),
                'overhead_percentage': round(overhead_percentage, 1),
                'time_saved_estimate': round(time_saved_estimate, 2)
            }
            
            # Update statistics
            self.stats['processed'] += 1
            self.stats['successful'] += 1
            self.stats['total_audio_duration'] += audio_duration
            self.stats['total_processing_time'] += total_time
            
            # Performance logging
            if self.perf_logger:
                self.perf_logger.log_processing(result)
            
            logger.info(f"  ✓ Completed in {total_time:.1f}s total "
                       f"({overall_speed_ratio:.2f}x realtime)")
            
            return result
            
        except Exception as e:
            # FIXED: Proper error handling with all required fields
            self.stats['processed'] += 1
            self.stats['failed'] += 1
            
            logger.error(f"  ✗ Processing failed: {e}")
            logger.debug(traceback.format_exc())
            
            error_result = {
                'audio_file': file_name,
                'status': 'failed',
                'error': str(e),
                'error_type': type(e).__name__,
                'error_traceback': traceback.format_exc(),
                'processing': {
                    'model': self.model_name,
                    'device': self.device,
                    'timestamp': datetime.utcnow().isoformat() + 'Z'
                }
            }
            
            # Log to performance logger
            if self.perf_logger:
                self.perf_logger.log_processing(error_result)
            
            return error_result
    
    def get_stats(self) -> Dict:
        """
        Get processing statistics with optimization metrics
        
        Returns:
            Dictionary with statistics including time saved
        """
        stats = self.stats.copy()
        
        if stats['successful'] > 0:
            stats['avg_processing_time_seconds'] = round(
                stats['total_processing_time'] / stats['successful'], 2
            )
            stats['avg_speed_ratio'] = round(
                stats['total_audio_duration'] / stats['total_processing_time'], 2
            )
        else:
            stats['avg_processing_time_seconds'] = 0
            stats['avg_speed_ratio'] = 0
        
        stats['device'] = self.device
        stats['model'] = self.model_name
        
        # Log session summary
        if self.perf_logger:
            self.perf_logger.log_session_summary(stats)
        
        return stats
    
    def reset_stats(self):
        """Reset statistics counters"""
        self.stats = {
            'processed': 0,
            'successful': 0,
            'failed': 0,
            'total_audio_duration': 0.0,
            'total_processing_time': 0.0,
            'estimated_time_saved': 0.0,
        }
    
    def close(self):
        """Clean up resources and close performance logger"""
        if self.perf_logger:
            self.perf_logger.close()
            logger.info(f"Performance logs saved to: {self.perf_logger.log_file}")


# ============================================================================
# STANDALONE TESTING
# ============================================================================

def test_processor():
    """Test the processor with a sample file"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s | %(levelname)-8s | %(message)s'
    )
    
    import argparse
    parser = argparse.ArgumentParser(description='Test Fixed Whisper Processor')
    parser.add_argument('audio_file', help='Audio file to process')
    parser.add_argument('--model', default=MODEL_NAME, help='Model name')
    parser.add_argument('--beam-size', type=int, default=BEAM_SIZE, help='Beam size')
    parser.add_argument('--no-transcription', action='store_true', 
                       help='Skip saving transcription')
    parser.add_argument('--no-translation', action='store_true',
                       help='Skip translation')
    parser.add_argument('--no-perf-log', action='store_true',
                       help='Disable performance logging')
    
    args = parser.parse_args()
    
    # Initialize processor
    processor = WhisperProcessor(
        model_name=args.model,
        enable_perf_logging=not args.no_perf_log
    )
    
    # Process file
    result = processor.process_audio_file(
        args.audio_file,
        beam_size=args.beam_size,
        save_transcription=not args.no_transcription,
        save_translation=not args.no_translation
    )
    
    # Print result
    import json
    print("\n" + "="*80)
    print("RESULT")
    print("="*80)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    # Print stats
    print("\n" + "="*80)
    print("STATISTICS")
    print("="*80)
    stats = processor.get_stats()
    print(json.dumps(stats, indent=2))
    
    # Close processor
    processor.close()
    
    if not args.no_perf_log:
        print(f"\nPerformance logs saved to: {processor.perf_logger.log_file}")


if __name__ == "__main__":
    test_processor()