#!/usr/bin/env python3
"""
Azure Storage Manager with Batch Operations
Complete single-file implementation with batch move & delete
"""

import os
import json
import traceback
import sys
import argparse
import time
from pathlib import Path
from typing import Dict, Optional, List
from datetime import datetime
from azure.storage.blob import BlobServiceClient, ContainerClient
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError


# ============================================================================
# ENVIRONMENT CONFIGURATION
# ============================================================================

class EnvironmentConfig:
    """Simplified configuration using connection string"""
    
    CONNECTION_STRING = os.environ.get('AZURE_STORAGE_CONNECTION_STRING', '')
    RECORDINGS_CONTAINER = os.environ.get('RECORDINGS_CONTAINER', 'recordings')
    TRANSCRIPTIONS_CONTAINER = os.environ.get('TRANSCRIPTIONS_CONTAINER', 'transcriptions')
    PROCESSED_RECORDINGS_CONTAINER = os.environ.get('PROCESSED_RECORDINGS_CONTAINER', 'processed-recordings')
    BATCH_SIZE = int(os.environ.get('BATCH_SIZE', '10'))
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    
    # Email configuration for notifications
    EMAIL_RECIPIENTS = os.environ.get('EMAIL_RECIPIENTS', '').split(',')
    SMTP_SERVER = os.environ.get('SMTP_SERVER', 'smtp.gmail.com')
    SMTP_PORT = int(os.environ.get('SMTP_PORT', '587'))
    SMTP_USERNAME = os.environ.get('SMTP_USERNAME', '')
    SMTP_PASSWORD = os.environ.get('SMTP_PASSWORD', '')
    EMAIL_FROM = os.environ.get('EMAIL_FROM', SMTP_USERNAME)
    
    @classmethod
    def get_blob_client(cls) -> BlobServiceClient:
        """Create Azure Blob Storage client using connection string"""
        
        if not cls.CONNECTION_STRING:
            raise ValueError(
                "AZURE_STORAGE_CONNECTION_STRING environment variable is required!\n"
                "Set it like this:\n"
                "  export AZURE_STORAGE_CONNECTION_STRING='your_connection_string_here'\n"
                "Or pass it when running:\n"
                "  AZURE_STORAGE_CONNECTION_STRING='...' python azure_manager.py process"
            )
        
        print("="*80)
        print("AZURE STORAGE CONNECTION")
        print("="*80)
        print("Connection: Connection String")
        print(f"Recordings Container: {cls.RECORDINGS_CONTAINER}")
        print(f"Transcriptions Container: {cls.TRANSCRIPTIONS_CONTAINER}")
        print(f"Processed Recordings Container: {cls.PROCESSED_RECORDINGS_CONTAINER}")
        print(f"Batch Size: {cls.BATCH_SIZE}")
        
        try:
            client = BlobServiceClient.from_connection_string(cls.CONNECTION_STRING)
            account_info = client.get_account_information()
            print("✓ Connected successfully")
            print(f"Account Kind: {account_info.get('account_kind', 'Unknown')}")
            print("="*80 + "\n")
            return client
            
        except Exception as e:
            print(f"✗ Connection failed: {e}")
            print("\nPlease check your connection string format.")
            print("It should look like:")
            print("  DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...;EndpointSuffix=core.windows.net")
            print("="*80 + "\n")
            raise


# ============================================================================
# EMAIL NOTIFICATION SYSTEM
# ============================================================================

class EmailNotifier:
    """Send email notifications for batch processing results"""
    
    def __init__(self):
        self.recipients = [r.strip() for r in EnvironmentConfig.EMAIL_RECIPIENTS if r.strip()]
        self.smtp_server = EnvironmentConfig.SMTP_SERVER
        self.smtp_port = EnvironmentConfig.SMTP_PORT
        self.username = EnvironmentConfig.SMTP_USERNAME
        self.password = EnvironmentConfig.SMTP_PASSWORD
        self.email_from = EnvironmentConfig.EMAIL_FROM
        
        self.enabled = bool(self.recipients and self.username and self.password)
    
    def send_batch_report(self, stats: Dict, errors: List[str] = None):
        """Send batch processing report via email"""
        if not self.enabled:
            print("Email notifications disabled (missing configuration)")
            return False
        
        try:
            import smtplib
            from email.mime.text import MIMEText
            from email.mime.multipart import MIMEMultipart
            
            # Create email
            msg = MIMEMultipart('alternative')
            msg['Subject'] = f"Azure Batch Processing Report - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            msg['From'] = self.email_from
            msg['To'] = ', '.join(self.recipients)
            
            # Create email body
            html_body = self._create_html_report(stats, errors)
            text_body = self._create_text_report(stats, errors)
            
            msg.attach(MIMEText(text_body, 'plain'))
            msg.attach(MIMEText(html_body, 'html'))
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.username, self.password)
                server.send_message(msg)
            
            print(f"✓ Email report sent to {len(self.recipients)} recipient(s)")
            return True
            
        except Exception as e:
            print(f"✗ Failed to send email: {e}")
            traceback.print_exc()
            return False
    
    def _create_text_report(self, stats: Dict, errors: List[str] = None) -> str:
        """Create plain text email report"""
        lines = [
            "AZURE BATCH PROCESSING REPORT",
            "=" * 80,
            f"Session Time: {stats.get('session_start', 'N/A')}",
            f"Duration: {stats.get('total_duration_seconds', 0):.2f}s ({stats.get('total_duration_seconds', 0)/60:.1f} minutes)",
            "",
            "STATISTICS:",
            f"  Total Batches: {stats.get('total_batches', 0)}",
            f"  Files Processed: {stats.get('processed', 0)}",
            f"  Successful: {stats.get('successful', 0)}",
            f"  Failed: {stats.get('failed', 0)}",
            f"  Moved to Processed: {stats.get('moved', 0)}",
            f"  Deleted from Source: {stats.get('deleted', 0)}",
            f"  Deletion Failures: {stats.get('deletion_failures', 0)}",
        ]
        
        if stats.get('successful', 0) > 0:
            lines.extend([
                f"  Success Rate: {(stats['successful']/stats['processed'])*100:.1f}%",
                f"  Avg Time per File: {stats.get('total_duration_seconds', 0)/stats['successful']:.2f}s"
            ])
        
        if errors:
            lines.extend([
                "",
                "ERRORS ENCOUNTERED:",
                "-" * 80
            ])
            for error in errors[:10]:
                lines.append(f"  • {error}")
            if len(errors) > 10:
                lines.append(f"  ... and {len(errors)-10} more errors")
        
        lines.append("\n" + "=" * 80)
        return "\n".join(lines)
    
    def _create_html_report(self, stats: Dict, errors: List[str] = None) -> str:
        """Create HTML email report"""
        success_rate = 0
        if stats.get('processed', 0) > 0:
            success_rate = (stats['successful']/stats['processed'])*100
        
        status_color = "#28a745" if success_rate >= 90 else "#ffc107" if success_rate >= 70 else "#dc3545"
        
        html = f"""
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px;">
                    Azure Batch Processing Report
                </h2>
                
                <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
                    <p style="margin: 5px 0;"><strong>Session Time:</strong> {stats.get('session_start', 'N/A')}</p>
                    <p style="margin: 5px 0;"><strong>Duration:</strong> {stats.get('total_duration_seconds', 0)/60:.1f} minutes</p>
                </div>
                
                <h3 style="color: #2c3e50; margin-top: 30px;">Processing Statistics</h3>
                <table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
                    <tr style="background-color: #ecf0f1;">
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Total Batches</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">{stats.get('total_batches', 0)}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Files Processed</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">{stats.get('processed', 0)}</td>
                    </tr>
                    <tr style="background-color: #d4edda;">
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Successful</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: #28a745;">{stats.get('successful', 0)}</td>
                    </tr>
                    <tr style="background-color: #f8d7da;">
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Failed</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: #dc3545;">{stats.get('failed', 0)}</td>
                    </tr>
                    <tr style="background-color: #d1ecf1;">
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Moved to Processed</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: #0c5460;">{stats.get('moved', 0)}</td>
                    </tr>
                    <tr style="background-color: #d1ecf1;">
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Deleted from Source</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: #0c5460;">{stats.get('deleted', 0)}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Success Rate</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: {status_color}; font-weight: bold;">{success_rate:.1f}%</td>
                    </tr>
                </table>
        """
        
        if errors:
            html += f"""
                <h3 style="color: #dc3545; margin-top: 30px;">⚠ Errors Encountered</h3>
                <div style="background-color: #f8d7da; border-left: 4px solid #dc3545; padding: 15px; margin: 15px 0;">
                    <ul style="margin: 0; padding-left: 20px;">
            """
            for error in errors[:10]:
                html += f"<li style='margin: 5px 0;'>{error}</li>"
            if len(errors) > 10:
                html += f"<li style='margin: 5px 0; font-style: italic;'>... and {len(errors)-10} more errors</li>"
            html += """
                    </ul>
                </div>
            """
        
        html += """
                <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 12px;">
                    <p>This is an automated report from your Azure Batch Processing system.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html

class AzureManager:
    """Azure Storage Manager with batch move and delete operations"""
    
    def __init__(self):
        """Initialize manager with connection string"""
        self.blob_client = EnvironmentConfig.get_blob_client()
        
        self.recordings_container = EnvironmentConfig.RECORDINGS_CONTAINER
        self.transcriptions_container = EnvironmentConfig.TRANSCRIPTIONS_CONTAINER
        self.processed_container = EnvironmentConfig.PROCESSED_RECORDINGS_CONTAINER
        self.batch_size = EnvironmentConfig.BATCH_SIZE
        
        # Email notifier
        self.email_notifier = EmailNotifier()
        
        # Temp directory for downloads
        self.temp_dir = Path('./temp_audio_processing')
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        
        # Statistics tracking
        self.processing_stats = {
            'processed': 0,
            'successful': 0,
            'failed': 0,
            'moved': 0,
            'deleted': 0,
            'deletion_failures': 0,
            'total_batches': 0,
            'batch_details': [],
            'errors': []
        }
        
        print(f"Temp Directory: {self.temp_dir}")
        print(f"Email Notifications: {'ENABLED' if self.email_notifier.enabled else 'DISABLED'}")
        if self.email_notifier.enabled:
            print(f"  Recipients: {', '.join(self.email_notifier.recipients)}")
        print()
    
    def is_already_processed(self, recording_blob_name: str) -> bool:
        """
        Check if a recording has already been processed.
        Only checks for transcription existence.
        
        API Calls: 1 per file
        """
        transcription_path = recording_blob_name.rsplit('.', 1)[0] + '_transcription.json'
        
        try:
            blob_client = self.blob_client.get_blob_client(
                self.transcriptions_container,
                transcription_path
            )
            blob_client.get_blob_properties()
            return True
        
        except ResourceNotFoundError:
            return False
        
        except Exception as e:
            print(f"  ⚠ Error checking transcription: {e}")
            return False
    
    def get_all_pending_recordings(self) -> List[str]:
        """
        Get ALL pending recordings from container.
        
        API Calls:
        - 1 to list all blobs (pagination handled internally)
        - 1 per audio file to check transcription
        Total: 1 + N (where N = number of audio files)
        """
        container_client = self.blob_client.get_container_client(
            self.recordings_container
        )
        
        audio_extensions = {'.mp3', '.wav', '.m4a', '.flac', '.ogg', 
                           '.MP3', '.WAV', '.M4A', '.FLAC', '.OGG'}
        
        pending = []
        orphans = []
        total_checked = 0
        audio_files_found = 0
        
        print("Scanning ALL recordings in container...")
        print(f"Container: {self.recordings_container}")
        print()
        
        try:
            for blob in container_client.list_blobs():
                total_checked += 1
                
                if total_checked % 100 == 0:
                    print(f"  Scanned {total_checked} blobs so far...")
                
                is_audio = any(blob.name.endswith(ext) for ext in audio_extensions)
                if not is_audio:
                    continue
                
                audio_files_found += 1
                
                if self.is_already_processed(blob.name):
                    orphans.append(blob.name)
                else:
                    pending.append(blob.name)
        
        except Exception as e:
            print(f"\n⚠ Error during scan: {e}")
            raise
        
        print(f"\n✓ Scan complete!")
        print(f"  Total blobs checked: {total_checked}")
        print(f"  Audio files found: {audio_files_found}")
        print(f"  Pending files: {len(pending)}")
        print(f"  Orphans (has transcription): {len(orphans)}")
        print()
        
        if orphans:
            print(f"Found {len(orphans)} orphaned files")
            print("These have transcriptions but weren't moved to processed-recordings")
            print("Moving them now...\n")
            self._move_orphans_to_processed(orphans)
        
        return pending
    
    def _move_orphans_to_processed(self, orphan_files: List[str]):
    """
    Move orphaned files to processed-recordings without reprocessing.
    Now tracks statistics properly!
    
    API Calls per file:
    - 1 to download from recordings
    - 1 to upload to processed-recordings
    - 1 to get source properties (for size)
    - 1 to get dest properties (for verification)
    - 1 to delete from recordings
    Total: 5 per orphan file
    """
    print("="*80)
    print("MOVING ORPHANED FILES")
    print("="*80)
    
    # Track orphan stats separately
    orphan_stats = {'moved': 0, 'deleted': 0, 'failed': 0}
    
    for blob_name in orphan_files:
        try:
            print(f"  Processing orphan: {blob_name}")
            
            source_blob = self.blob_client.get_blob_client(
                self.recordings_container,
                blob_name
            )
            data = source_blob.download_blob().readall()
            
            dest_blob = self.blob_client.get_blob_client(
                self.processed_container,
                blob_name
            )
            dest_blob.upload_blob(data, overwrite=True)
            
            source_size = source_blob.get_blob_properties().size
            dest_size = dest_blob.get_blob_properties().size
            
            if source_size == dest_size:
                source_blob.delete_blob()
                orphan_stats['moved'] += 1
                orphan_stats['deleted'] += 1
                print(f"    ✓ Moved and deleted: {blob_name}")
            else:
                orphan_stats['failed'] += 1
                error_msg = f"Orphan size mismatch: {blob_name} (source={source_size}, dest={dest_size})"
                print(f"    ⚠ Size mismatch, keeping in recordings: {blob_name}")
                self.processing_stats['errors'].append(error_msg)
                
        except Exception as e:
            orphan_stats['failed'] += 1
            error_msg = f"Orphan move failed for {blob_name}: {str(e)}"
            print(f"    ✗ Failed to move {blob_name}: {e}")
            self.processing_stats['errors'].append(error_msg)
    
    self.processing_stats['moved'] += orphan_stats['moved']
    self.processing_stats['deleted'] += orphan_stats['deleted']
    self.processing_stats['deletion_failures'] += orphan_stats['failed']
    
    # Print summary
    print("="*80)
    print(f"Orphan Cleanup Summary:")
    print(f"  Moved: {orphan_stats['moved']}")
    print(f"  Deleted: {orphan_stats['deleted']}")
    print(f"  Failed: {orphan_stats['failed']}")
    print("="*80 + "\n")

    def process_single_file(self, blob_name: str, processor, file_idx: int, batch_idx: int) -> Dict:
        """
        Process a single audio file: download, transcribe, upload transcription.
        Does NOT move to processed-recordings or delete (done in batch).
        
        API Calls per file:
        - 1 to download from recordings
        - 1 to upload transcription
        Total: 2 per file
        """
        local_path = self.temp_dir / blob_name.split('/')[-1]
        
        file_start_time = time.time()
        
        result = {
            'blob_name': blob_name,
            'local_path': str(local_path),
            'success': False,
            'file_index': file_idx,
            'batch_index': batch_idx,
            'error': None
        }
        
        try:
            print("  [1/3] Downloading...")
            blob_client = self.blob_client.get_blob_client(
                self.recordings_container,
                blob_name
            )
            
            with open(local_path, 'wb') as f:
                download_stream = blob_client.download_blob()
                f.write(download_stream.readall())
            
            file_size = local_path.stat().st_size
            print(f"        ✓ Downloaded ({file_size:,} bytes)")
            
            print("  [2/3] Processing with Whisper...")
            whisper_result = processor.process_audio_file(str(local_path))
            
            if whisper_result.get('status') != 'success':
                error_msg = whisper_result.get('error', 'Unknown error')
                print(f"        ✗ Processing failed: {error_msg}")
                result['error'] = error_msg
                self.processing_stats['errors'].append(f"{blob_name}: {error_msg}")
                return result
            
            print(f"Processed successfully")
            
            print("  [3/3] Uploading transcription...")
            transcription_path = blob_name.rsplit('.', 1)[0] + '_transcription.json'
            result_json = json.dumps(whisper_result, indent=2, ensure_ascii=False)
            
            trans_blob_client = self.blob_client.get_blob_client(
                self.transcriptions_container,
                transcription_path
            )
            trans_blob_client.upload_blob(
                result_json.encode('utf-8'),
                overwrite=True
            )
            
            print(f"Transcription uploaded")
            
            result['success'] = True
            result['total_time'] = time.time() - file_start_time
            
        except Exception as e:
            print(f"  ✗ Unexpected error: {e}")
            result['error'] = str(e)
            self.processing_stats['errors'].append(f"{blob_name}: {str(e)}")
        
        return result
    
    def batch_move_and_delete(self, successful_files: List[Dict]) -> Dict:
        """
        Move all successfully processed files to processed-recordings,
        then delete from recordings after verification.
        
        API Calls per file:
        - 1 to upload to processed-recordings
        - 1 to get source properties (size)
        - 1 to get dest properties (size)
        - 1 to delete from recordings
        Total: 4 per file
        """
        if not successful_files:
            return {
                'moved': 0,
                'deleted': 0,
                'move_failures': 0,
                'delete_failures': 0
            }
        
        stats = {
            'moved': 0,
            'deleted': 0,
            'move_failures': 0,
            'delete_failures': 0
        }
        
        print("\n" + "="*80)
        print("📦 BATCH MOVE & DELETE")
        print("="*80)
        print(f"Files to process: {len(successful_files)}\n")
        
        print("[1/3] Uploading to processed-recordings...")
        moved_files = []
        
        for file_info in successful_files:
            blob_name = file_info['blob_name']
            local_path = Path(file_info['local_path'])
            
            if not local_path.exists():
                print(f"  ✗ Local file not found: {blob_name}")
                stats['move_failures'] += 1
                continue
            
            try:
                processed_blob = self.blob_client.get_blob_client(
                    self.processed_container,
                    blob_name
                )
                
                with open(local_path, 'rb') as data:
                    processed_blob.upload_blob(data, overwrite=True)
                
                moved_files.append(blob_name)
                stats['moved'] += 1
                print(f"  ✓ Uploaded: {blob_name}")
                
            except Exception as e:
                stats['move_failures'] += 1
                error_msg = f"Failed to upload {blob_name} to processed-recordings: {str(e)}"
                print(f"  ✗ {error_msg}")
                self.processing_stats['errors'].append(error_msg)
        
        print(f"\n[2/3] Verifying {len(moved_files)} uploaded files...")
        verified_files = []
        
        for blob_name in moved_files:
            try:
                source_blob = self.blob_client.get_blob_client(
                    self.recordings_container,
                    blob_name
                )
                source_size = source_blob.get_blob_properties().size
                
                dest_blob = self.blob_client.get_blob_client(
                    self.processed_container,
                    blob_name
                )
                dest_size = dest_blob.get_blob_properties().size
                
                if source_size == dest_size:
                    verified_files.append(blob_name)
                    print(f"  ✓ Verified: {blob_name} ({source_size:,} bytes)")
                else:
                    stats['delete_failures'] += 1
                    error_msg = f"Size mismatch for {blob_name}: source={source_size}, dest={dest_size}"
                    print(f"  ✗ {error_msg}")
                    self.processing_stats['errors'].append(error_msg)
                    
            except Exception as e:
                stats['delete_failures'] += 1
                error_msg = f"Verification failed for {blob_name}: {str(e)}"
                print(f"  ✗ {error_msg}")
                self.processing_stats['errors'].append(error_msg)
        
        print(f"\n[3/3] Deleting {len(verified_files)} verified files from recordings...")
        
        for blob_name in verified_files:
            try:
                source_blob = self.blob_client.get_blob_client(
                    self.recordings_container,
                    blob_name
                )
                source_blob.delete_blob()
                
                stats['deleted'] += 1
                print(f"  ✓ Deleted: {blob_name}")
                
            except Exception as e:
                stats['delete_failures'] += 1
                error_msg = f"Deletion failed for {blob_name}: {str(e)}"
                print(f"  ✗ {error_msg}")
                self.processing_stats['errors'].append(error_msg)
        
        print(f"\nCleaning up {len(successful_files)} local temp files...")
        for file_info in successful_files:
            local_path = Path(file_info['local_path'])
            if local_path.exists():
                try:
                    local_path.unlink()
                except Exception as e:
                    print(f"  ⚠ Failed to delete temp file: {local_path}")
        
        print("\n" + "="*80)
        print(f"✓ BATCH OPERATIONS COMPLETE")
        print(f"  Moved: {stats['moved']}/{len(successful_files)}")
        print(f"  Deleted: {stats['deleted']}/{len(successful_files)}")
        if stats['move_failures'] > 0:
            print(f"  Move Failures: {stats['move_failures']}")
        if stats['delete_failures'] > 0:
            print(f"  Delete Failures: {stats['delete_failures']}")
        print("="*80 + "\n")
        
        return stats
    
    def process_all_pending(self, batch_size: Optional[int] = None):
        """
        Process ALL pending files in batches with batch move & delete.
        
        Total API Calls:
        - Scanning: 1 + N (where N = audio files in recordings)
        - Per file processing: 2 (download + upload transcription)
        - Per batch move/delete: 4 per file (upload + verify + delete)
        - Orphan handling: 5 per orphan
        """
        batch_size = batch_size or self.batch_size
        
        print("="*80)
        print("COMPLETE BATCH PROCESSING - ALL PENDING FILES")
        print("="*80)
        print(f"Batch size: {batch_size} files per batch")
        print("="*80 + "\n")
        
        session_start_time = time.time()
        
        self.processing_stats = {
            'processed': 0,
            'successful': 0,
            'failed': 0,
            'moved': 0,
            'deleted': 0,
            'deletion_failures': 0,
            'total_batches': 0,
            'batch_details': [],
            'errors': [],
            'session_start': datetime.now().isoformat(),
        }
        
        all_pending = self.get_all_pending_recordings()
        
        if not all_pending:
            print("✓ No pending recordings to process!\n")
            if self.email_notifier.enabled:
                self.email_notifier.send_batch_report(self.processing_stats)
            return self.processing_stats
        
        total_files = len(all_pending)
        total_batches = (total_files + batch_size - 1) // batch_size
        
        print(f"PROCESSING PLAN")
        print(f"  Total pending files: {total_files}")
        print(f"  Batch size: {batch_size}")
        print(f"  Total batches: {total_batches}")
        print()
        
        try:
            from whisper_processor import WhisperProcessor
        except ImportError:
            print("Cannot import WhisperProcessor")
            return self.processing_stats
        
        try:
            print("Initializing Whisper processor...")
            processor = WhisperProcessor()
            print()
        except Exception as e:
            print(f"✗ Failed to initialize Whisper: {e}")
            return self.processing_stats
        
        for batch_num in range(total_batches):
            batch_start_time = time.time()
            
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, total_files)
            batch_files = all_pending[start_idx:end_idx]
            batch_size_actual = len(batch_files)
            
            print("="*80)
            print(f"BATCH {batch_num + 1} of {total_batches}")
            print("="*80)
            print(f"Files: {batch_size_actual} | Range: {start_idx + 1}-{end_idx} of {total_files}")
            print("="*80 + "\n")
            
            successful_files = []
            
            for idx, blob_name in enumerate(batch_files, 1):
                global_idx = start_idx + idx
                print(f"[File {idx}/{batch_size_actual} | Global {global_idx}/{total_files}] {blob_name}")
                
                file_result = self.process_single_file(blob_name, processor, global_idx, batch_num + 1)
                
                self.processing_stats['processed'] += 1
                
                if file_result['success']:
                    self.processing_stats['successful'] += 1
                    successful_files.append(file_result)
                    print(f"  ✓ SUCCESS\n")
                else:
                    self.processing_stats['failed'] += 1
                    print(f"  ✗ FAILED: {file_result.get('error', 'Unknown error')}\n")
            
            if successful_files:
                move_stats = self.batch_move_and_delete(successful_files)
                self.processing_stats['moved'] += move_stats['moved']
                self.processing_stats['deleted'] += move_stats['deleted']
                self.processing_stats['deletion_failures'] += move_stats['delete_failures']
            else:
                move_stats = {'moved': 0, 'deleted': 0}
            
            batch_elapsed = time.time() - batch_start_time
            self.processing_stats['total_batches'] += 1
            
            print("="*80)
            print(f"BATCH {batch_num + 1} COMPLETE - {batch_elapsed:.2f}s")
            print(f"  Processed: {len(successful_files)}/{batch_size_actual}")
            print(f"  Moved: {move_stats.get('moved', 0)}")
            print(f"  Deleted: {move_stats.get('deleted', 0)}")
            print("="*80 + "\n")
        
        session_elapsed = time.time() - session_start_time
        self.processing_stats['session_end'] = datetime.now().isoformat()
        self.processing_stats['total_duration_seconds'] = round(session_elapsed, 2)
        
        self._print_session_summary(session_elapsed)
        
        if self.email_notifier.enabled:
            self.email_notifier.send_batch_report(
                self.processing_stats, 
                self.processing_stats['errors']
            )
        
        return self.processing_stats
    
    def _print_session_summary(self, session_elapsed: float):
        """Print detailed session summary"""
        print("\n" + "="*80)
        print("SESSION COMPLETE")
        print("="*80)
        print(f"Duration: {session_elapsed/60:.1f} minutes")
        print(f"Total Batches: {self.processing_stats['total_batches']}")
        print(f"Files Processed: {self.processing_stats['processed']}")
        print(f"Successful: {self.processing_stats['successful']}")
        print(f"Failed: {self.processing_stats['failed']}")
        print(f"Moved to Processed: {self.processing_stats['moved']}")
        print(f"Deleted from Source: {self.processing_stats['deleted']}")
        print(f"Deletion Failures: {self.processing_stats['deletion_failures']}")
        
        if self.processing_stats['processed'] > 0:
            success_rate = (self.processing_stats['successful'] / self.processing_stats['processed']) * 100
            print(f"Success Rate: {success_rate:.1f}%")
        
        print("="*80)
        print()
    
    def setup_test_environment(self):
        """Create containers if they don't exist"""
        print("Setting up containers...")
        
        for container_name in [self.recordings_container, self.transcriptions_container, self.processed_container]:
            try:
                self.blob_client.create_container(container_name)
                print(f"  ✓ Created: {container_name}")
            except ResourceExistsError:
                print(f"  → Exists: {container_name}")
        
        print("\n✓ Environment ready!\n")



def main():
    """CLI for Azure Manager"""
    parser = argparse.ArgumentParser(description='Azure Storage Manager with Batch Operations')
    parser.add_argument('command', choices=['setup', 'process', 'test-email'], help='Command to execute')
    parser.add_argument('--batch-size', type=int, help='Files per batch (overrides env variable)')
    
    args = parser.parse_args()
    
    try:
        manager = AzureManager()
        
        if args.command == 'setup':
            manager.setup_test_environment()
        
        elif args.command == 'process':
            manager.process_all_pending(batch_size=args.batch_size)
        
        elif args.command == 'test-email':
            print("Testing email configuration...")
            test_stats = {
                'session_start': datetime.now().isoformat(),
                'total_duration_seconds': 123.45,
                'total_batches': 2,
                'processed': 10,
                'successful': 9,
                'failed': 1,
                'moved': 9,
                'deleted': 8,
                'deletion_failures': 1
            }
            test_errors = ['Test error 1', 'Test error 2']
            success = manager.email_notifier.send_batch_report(test_stats, test_errors)
            if success:
                print("✓ Test email sent successfully!")
            else:
                print("✗ Test email failed - check your configuration")
    
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\nError: {e}")
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()